GitHub Pages 部署说明：

1. 新建 GitHub 仓库
2. 上传 index.html
3. Settings -> Pages
4. Branch 选 main / root
5. 等待生成网址

你会得到：
https://xxx.github.io/xxx/
